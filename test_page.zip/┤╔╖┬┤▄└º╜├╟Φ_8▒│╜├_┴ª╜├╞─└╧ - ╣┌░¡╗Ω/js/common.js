$(function() {
  $.ajax({
    url: 'data.xml',
    dataType: 'xml',
    success: function(data) {
      $('item', data).each(function() {
        let linkText = $('link', this).text();
        let titleText = $('title', this).text();
        let descriptionText = $('description', this).text();
        $('dl').append(`<dt><a href=${linkText}>${titleText}</a></dt><dd>${descriptionText}</dd>`)
      });
    }
  });
  $('button').click(function() {
    if ($(this).hasClass('on')) {
      $(this).removeClass('on');
    } else {
      $(this).addClass('on');
    };
  });
});
